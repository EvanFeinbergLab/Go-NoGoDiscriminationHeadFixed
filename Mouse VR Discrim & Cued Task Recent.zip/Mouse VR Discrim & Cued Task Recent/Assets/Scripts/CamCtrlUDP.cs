﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using System.Threading;


public class CamCtrlUDP : MonoBehaviour {

    private Vector3 oldPos;
    private Vector3 newPos;

    private Thread receiveThread;
    // is the script still running
    private bool mRunning;
    // udpclient object
    UdpClient client;
    // UDP port
    public int port;
    // received packet
    private byte[] data;
    private string text;
    private string PosIn;
    private string Stim;
    public int gridStim;
    private int stringSize; 

    public GameObject Ground;

    private float distance; //cam location
    private float position; //UDP position
    private float oldPosition;
    private float smoothing = 1f;
    private float fracMovt;
    private float CloneOrigin;

    private int FwdInstanNum;
    private int RevInstanNum;
    private int InstanLength;
    private int origin;
    private int numstartclones;   
    private int iteration;
    private int revNum; 

    public string lastReceivedUDPPacket = "";
    private string startFwdI;
    private string startRevI;
    private string CloneNum;
    private string nameNum;
    private string PrevCloneNum;
    private string PrevCloneName;
    private string clonename;
    private string iterationString;
    private string tempArray;
    private string PrevCloneI;
    private string OrigCloneName;
    private string StartCloneName; 

    public GameObject Grid;
    private GameObject GridClone;
    public Transform GridTarget;
    public Transform GridPoint; 

    public bool CloneExists;
    public bool EndHall; 

    private float offset;
    private float X;
    private float Y;
    private float targetZ;
    
    private float camZ;
    private float targetOffset;

//trying more start clones but shorter 
// might also try clones the start clone as the cam is approaching
    void Awake()
    {
        numstartclones = 41; // length of one clone = ~50 x InstanNum
        origin = 5;
        FwdInstanNum = 1001; //total hallway length = ~ #startclones x length of one clone
        RevInstanNum = 21; 
        InstanLength = (FwdInstanNum - 1) * 50; //50 is the length of one ground prefab

        for (int i = 1; i < FwdInstanNum; i++) //if too big slows down grid
        {
            startFwdI = Convert.ToString(i);
            GameObject GroundClone = Instantiate(Ground) as GameObject;
            GroundClone.name = "Ground1_" + startFwdI;
            GroundClone.transform.position = new Vector3(0.0f, 0.0f, i * 50.0f + origin);
        }

        for (int i = 1; i < RevInstanNum; i++)
        {           
            revNum = (FwdInstanNum - 1) + i;
            startRevI = Convert.ToString(revNum);
            GameObject GroundClone = Instantiate(Ground) as GameObject;
            GroundClone.name = "Ground1_" + startRevI;
            GroundClone.transform.position = new Vector3(0.0f, 0.0f, i * -50.0f + origin);
        }

        for (int i = 1; i < numstartclones; i++)
        {
            GameObject GroundObj = Instantiate(Ground) as GameObject;
            nameNum = Convert.ToString(i+1);
            GroundObj.name = "Ground" + nameNum;
            GroundObj.transform.position = new Vector3(0.0f, 0.0f, i * InstanLength + origin); 
        }

        //Grid Control 

        X = GridPoint.transform.position.x;
        Y = GridPoint.transform.position.y;
        targetZ = GridTarget.transform.position.z;
        camZ = transform.position.z;

        offset = GridPoint.transform.position.z - camZ;
        targetOffset = targetZ - camZ;
    }

    //Grid Coroutine
    IEnumerator MoveStim()
    {
        if (CloneExists == true)
        {
            GridPoint.transform.position = Vector3.Lerp(GridPoint.transform.position, GridTarget.position, smoothing * Time.deltaTime);
            //edit out above line if you dont want the stimulus to slide 

            GridClone.transform.position = GridPoint.transform.position;
            yield return null;
        }
    }


    void Start()
    {
        init();

        iteration = 1;        
    }


    private void init()
    {
        print("UDPSend.init()");

        port = 61557;

        mRunning = true;
        receiveThread = new Thread(new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();
    }


    void Update()
    {       
        distance = transform.position.z;

        // take the UDP data and extract position and state
        tempArray = lastReceivedUDPPacket;
        stringSize = tempArray.Length;

        if (stringSize > 0)
        {
            Stim = tempArray.Substring(0, 1);
            PosIn = tempArray.Substring(1, (stringSize - 1));
        }     

        //float.TryParse(tempArray, out position);
        float.TryParse(PosIn, out position);
        int.TryParse(Stim, out gridStim); 

        fracMovt = smoothing * Time.deltaTime;

        //Cam Movement 
        if (position < 30000 && position != distance)
        {
            newPos = new Vector3(transform.position.x, transform.position.y, position);
            transform.position = Vector3.Lerp(oldPos, newPos, fracMovt);
        }

        //read out stim info from UDP
        if (gridStim > 0)
        {
            GridClone = Instantiate(Grid) as GameObject;
            GridClone.transform.position = GridPoint.transform.position;
            CloneExists = true;
        }

        if (CloneExists == true)
        {
            StartCoroutine("MoveStim");
        }

        // Clone the start clones when cam gets close 
        if (position > (InstanLength * iteration - 1200))
        {
            
            CloneNum = Convert.ToString(iteration + 1);
            clonename = "Ground" + CloneNum;
            GameObject CloneOfInterest = GameObject.Find(clonename);
            CloneOrigin = CloneOfInterest.transform.position.z;

            for (int i = 1; i < FwdInstanNum; i++)
            {
                iterationString = Convert.ToString(i);

                GameObject GroundFwdClone = Instantiate(CloneOfInterest) as GameObject;
                GroundFwdClone.name = clonename + "_" + iterationString;
                GroundFwdClone.transform.position = new Vector3(0.0f, 0.0f, CloneOrigin + (i * 50));
            }

            for (int i = 1; i < RevInstanNum; i++)
            {
                int totalIt = i + (FwdInstanNum - 1); 
                iterationString = Convert.ToString(totalIt);               

                GameObject GroundRevClone = Instantiate(Ground) as GameObject;
                GroundRevClone.name = clonename + "_" + iterationString;
                GroundRevClone.transform.position = new Vector3(0.0f, 0.0f, i * -50.0f + CloneOrigin);
            }

            iteration = iteration + 1;
        }

        if (iteration > 1 && position > (CloneOrigin + 50)) //modify so that the destruction of the start clones happen once -- may not be necessary
        {

            for (int i = 1; i < ((FwdInstanNum - 1) + (RevInstanNum)); i++)
            {
                PrevCloneNum = Convert.ToString(iteration - 1);
                PrevCloneI = Convert.ToString(i);

                PrevCloneName = "Ground" + PrevCloneNum + "_" + PrevCloneI;
                //OrigCloneName = "Ground" + PrevCloneNum;

                //string StartCloneName = "Ground1_" + PrevCloneI;

                //GameObject DestroyStart = GameObject.Find(StartCloneName);
                //GameObject DestroyOrig = GameObject.Find(OrigCloneName);
                GameObject CloneToDestroy = GameObject.Find(PrevCloneName);

                Destroy(CloneToDestroy);
               // Destroy(DestroyOrig);
                //Destroy(DestroyStart);
            }
        }

        //if (iteration == 2 && position > (CloneOrigin + 50))
        //{
          //  StartCloneName = "Ground";
          //  GameObject DestroyStartClone = GameObject.Find(StartCloneName);
          //  Destroy(DestroyStartClone);
       // }

        //if mous reaches end of the hall 
        if (position == 30000)
        {
            EndHall = true;
        }

        if (EndHall == true)
        {
            iteration = 1;

            for (int i = 1; i < FwdInstanNum; i++) 
            {
                startFwdI = Convert.ToString(i);
                GameObject GroundClone = Instantiate(Ground) as GameObject;
                GroundClone.name = "Ground1_" + startFwdI;
                GroundClone.transform.position = new Vector3(0.0f, 0.0f, i * 50.0f + origin);
            }

            for (int i = 1; i < RevInstanNum; i++)
            {
                revNum = (FwdInstanNum - 1) + i;
                startRevI = Convert.ToString(revNum);
                GameObject GroundClone = Instantiate(Ground) as GameObject;
                GroundClone.name = "Ground1_" + startRevI;
                GroundClone.transform.position = new Vector3(0.0f, 0.0f, i * -50.0f + origin);
            }

            for (int i = 1; i < numstartclones; i++)
            {
                GameObject GroundObj = Instantiate(Ground) as GameObject;
                nameNum = Convert.ToString(i + 1);
                GroundObj.name = "Ground" + nameNum;
                GroundObj.transform.position = new Vector3(0.0f, 0.0f, i * InstanLength + origin);
            }

            transform.position = new Vector3(0.0f, 1.0f, 0.0f);
            EndHall = false;
        }

    }
    


    void LateUpdate()
    {        

        oldPos = transform.position;

        //movement of grid with cam and destruction of grid 
        position = transform.position.z;
        GridTarget.transform.position = new Vector3(GridTarget.transform.position.x, GridTarget.transform.position.y, position + targetOffset);
        GridPoint.transform.position = new Vector3(GridPoint.transform.position.x, GridPoint.transform.position.y, position + offset);

        if (CloneExists == true)
        {
            GridClone.transform.position = GridPoint.transform.position;
        }

        if (CloneExists == true && GridPoint.transform.position.x >= -3.0f)
        {
            GridClone.SetActive(false);
            GridPoint.transform.position = new Vector3(X, Y, transform.position.z + offset);
        }
    }


    // receive thread 
    private void ReceiveData()
    {
        print("allocating client");
        IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, port);
        client = new UdpClient(port);
        client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (mRunning)
        {
            try
            {
                data = client.Receive(ref anyIP); //byte[] data
                text = Encoding.UTF8.GetString(data);
                // latest UDPpacket
                lastReceivedUDPPacket = text;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    public string getLatestUDPPacket()
    {

        return lastReceivedUDPPacket;
    }

    void OnApplicationQuit()
    {
        // stop listening thread
        mRunning = false;
        client.Close(); 

        // wait for listening thread to terminate (max. 500ms)		
        receiveThread.Join(500);
    }

}