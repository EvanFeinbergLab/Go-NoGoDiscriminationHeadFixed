﻿using UnityEngine;
using System.Collections;

public class GroundCtrl : MonoBehaviour
{
    public GameObject Ground;

    void Awake()
    {
        //set to 5000 for decent length and load time at start 
        for (int i = 0; i < 10; i++) //originally 200 
        {
            GameObject GroundClone = Instantiate(Ground) as GameObject;
            GroundClone.transform.position = new Vector3(transform.position.x, transform.position.y, i * 40.0f);

        }
        for (int i = 0; i < 10; i++)
        {
            GameObject GroundClone = Instantiate(Ground) as GameObject;
            GroundClone.transform.position = new Vector3(transform.position.x, transform.position.y, i * -40.0F);

        }
    }   
}
