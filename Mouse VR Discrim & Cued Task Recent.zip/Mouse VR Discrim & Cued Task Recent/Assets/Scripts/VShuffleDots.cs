﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Text.RegularExpressions;

public class VShuffleDots : MonoBehaviour {

    private float[] YCoords;
    private float RandY;
    private float RandDot;
    private string DotI;
    private string FindDotI;
    private GameObject VRWDotClone;
    private GameObject VLWDotClone;
    private GameObject VRBDotClone;
    private GameObject VLBDotClone;
    private GameObject ShuffleRDot;
    private GameObject ShuffleLDot;
    public GameObject WhiteDot;
    public GameObject BlackDot;

    public int Iteration;
    private float RandSeed;

    public bool Vloop; 

    // Use this for initialization
    void Start()
    {
        Iteration = 0; 

        // dots for vert corridor
        for (int i = 1; i < 250; i++)
        {
            RandY = UnityEngine.Random.Range(1.0f, 5.0f);
            RandDot = UnityEngine.Random.value;
            DotI = Convert.ToString(i);

            if (RandDot < 0.5f)
            {
                GameObject VRWDotClone = Instantiate(WhiteDot) as GameObject;
                GameObject VLWDotClone = Instantiate(WhiteDot) as GameObject;

                VRWDotClone.name = "VRDot" + DotI;
                VLWDotClone.name = "VLDot" + DotI;

                VRWDotClone.transform.position = new Vector3(15.02f, RandY, i * 2 + 80);
                VLWDotClone.transform.position = new Vector3(24.98f, RandY, i * 2 + 80);
            }

            if (RandDot > 0.5f)
            {
                GameObject VRBDotClone = Instantiate(BlackDot) as GameObject;
                GameObject VLBDotClone = Instantiate(BlackDot) as GameObject;

                VRBDotClone.name = "VRDot" + DotI;
                VLBDotClone.name = "VLDot" + DotI;

                VRBDotClone.transform.position = new Vector3(15.02f, RandY, i * 2 + 80);
                VLBDotClone.transform.position = new Vector3(24.98f, RandY, i * 2 + 80);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnBecameVisible()
    {
            // UnityEngine.Random.seed = RandSeed;

            for (int i = 0; i < 250; i++)
            {
                RandY = UnityEngine.Random.Range(1.0f, 5.0f);
                FindDotI = Convert.ToString(i);

                ShuffleRDot = GameObject.Find("VRDot" + FindDotI);
                ShuffleLDot = GameObject.Find("VLDot" + FindDotI);

                ShuffleRDot.transform.position = new Vector3(-4.98f, RandY, i * 2 + 60);
                ShuffleLDot.transform.position = new Vector3(4.98f, RandY, i * 2 + 60);

             }

        Iteration = Iteration + 1;      
    }

}

