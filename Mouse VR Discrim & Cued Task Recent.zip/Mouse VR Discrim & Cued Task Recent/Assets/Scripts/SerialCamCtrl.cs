﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.IO.Ports;


public class SerialCamCtrl : MonoBehaviour
{
    private float distance;

    private float oldPosition;
    private Vector3 oldPos;
    private Vector3 newPos;

    public int position; 

    private SerialPort port = new SerialPort("COM3", 57600);

    public float smoothing = 1f;

    public GameObject Ground;

    void Awake()
    {
        //set to 5000 for decent length and load time at start       

        for (int i = 0; i < 3; i++) //if too big slows down grid
        {
            GameObject GroundClone = Instantiate(Ground) as GameObject;
            GroundClone.transform.position = new Vector3(0.0f, 0.0f, i * 50.0F);
        }

        for (int i = 0; i < 3; i++)
        {
            GameObject GroundClone = Instantiate(Ground) as GameObject;
            GroundClone.transform.position = new Vector3(0.0f, 0.0f, i * -50.0F);
        }
    }

    void Start()
    {
        port.Open(); 
    }


    void Update()
    {
        distance = transform.position.z;
        oldPos = transform.position;

        port.DtrEnable = true;
        port.RtsEnable = true;

        try
        {
            byte[] buffer = new byte[port.ReadBufferSize];
            position = port.Read(buffer, 0, buffer.Length);

            if (position != distance)
            {
                newPos = new Vector3(transform.position.x, transform.position.y, position);
                transform.position = Vector3.Lerp(oldPos, newPos, smoothing * Time.deltaTime);
            }
        }
        catch (SystemException)
        {

        }

        //create new ground as the cam moves forward
        for (int i = 0; i <= position; i++)  // can add aBS POSITION later
        {
            if (position == i * 25)
            {
                GameObject GroundClone = Instantiate(Ground) as GameObject;
                GroundClone.transform.position = new Vector3(0.0f, 0.0f, (i + 2) * 50.0F);
            }

            if (position == i * -25)
            {
                GameObject GroundClone = Instantiate(Ground) as GameObject;
                GroundClone.transform.position = new Vector3(0.0f, 0.0f, (i + 2) * -50.0F);
            }
        }
    }
}