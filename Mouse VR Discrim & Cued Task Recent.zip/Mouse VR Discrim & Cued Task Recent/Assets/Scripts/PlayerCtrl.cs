﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class PlayerCtrl : MonoBehaviour {

    //want to check every frame for player input and then apply input every frame as movement 
    // Update = called before rendering frame, game code goes here -- dont need for rolling ball
    // Fixed Updated = called before any physics calc, physics code goes here 

    // public variable allows us to make changes in the editor in unity
    //private Rigidbody rb;

    private Thread receiveThread;
    // is the script still running
    private bool mRunning;
    // udpclient object
    UdpClient client;
    // UDP port
    public int port;
    // received packet
    public float smoothing = 1f;

    public string lastReceivedUDPPacket = "";

    // Use this for initialization

    void Start()
    {
        init();
        //rb = GetComponent<Rigidbody>();

        //mRunning = true;
        // receiveThread = new Thread(new ThreadStart(ReceiveData));
        // receiveThread.IsBackground = true;
        //  receiveThread.Start();
    }
    private void init()
    {
        print("UDPSend.init()");

        port = 61557; 

        mRunning = true;
        receiveThread = new Thread(new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();
    }

    void Update()
    {
        // take the UDP data and extract position and state
        string tempArray = lastReceivedUDPPacket;
        float position;
        float.TryParse(tempArray, out position);

        GameObject.Find("Player").transform.position = new Vector3(transform.position.x, transform.position.y, position);

        //newPos = transform.position;


        // move the camera using the position variableBerkeley
        //transform.position = coordinates;
    }

    void LateUpdate()
    {

        float distance = GameObject.Find("Player").transform.position.z;

        if (distance > 400f || distance < 400f) 
        {
            GameObject.Find("Player").transform.position = new Vector3(0.0f, 0.52f, 0.0f);            
        }
    }

    //void FixedUpdate()
   // {
        //Grabs input from player through keyboard
        //float variable record input from horizontal and vertical axes which are controlled by keys on keyboard 
       // float moveHorizontal = Input.GetAxis("Horizontal");
       // float moveVertical = Input.GetAxis("Vertical");

        //Vector3 movement = new Vector3 (0.0f, 0.0f, moveVertical);
       // rb.AddForce(movement * speed);
    
    //}
 

    // receive thread 
    private void ReceiveData()
    {
        print("allocating client");
        IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, port);
        client = new UdpClient(port);
        client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (mRunning)
        {
            try
            {
                byte[] data = client.Receive(ref anyIP);
                string text = Encoding.UTF8.GetString(data);
                // latest UDPpacket
                lastReceivedUDPPacket = text;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    public string getLatestUDPPacket()
    {
    
        return lastReceivedUDPPacket;
    }

    void OnApplicationQuit()
    {
        // stop listening thread
        mRunning = false;

        // wait for listening thread to terminate (max. 500ms)		
        receiveThread.Join(500);
    }

}
