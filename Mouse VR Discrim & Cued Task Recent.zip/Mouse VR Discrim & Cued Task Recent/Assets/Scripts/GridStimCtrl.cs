﻿using UnityEngine;
using System.Collections;

public class GridStimCtrl : MonoBehaviour {

    //private Rigidbody rb;
    private float offset;
    public float speed;

    void Start()
    {
        //rb = GetComponent<Rigidbody>();
        offset = transform.position.z - GameObject.Find("Player").transform.position.z;
    }

    void LateUpdate()
    {
        transform.position = new Vector3(transform.position.x, transform.position.y, GameObject.Find("Player").transform.position.z + offset);
    }

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        transform.position = transform.position + new Vector3(moveHorizontal, 0.0f, 0.0f);
        
    }
}
